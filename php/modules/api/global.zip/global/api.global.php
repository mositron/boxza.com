<?php

if(in_array(_::$path[1],array('chat')))
{
	require_once __DIR__.'/api.global.'._::$path[1].'.php';
}


?>